# nuked
Nuked Discord Selfbot




# What do I need for this?
you will need python version >= 3.8 and you will need it added to path, if you do not know how to do this, relaunch python setup and click add to path. if there is no option for that then uninstall python and reinstall it and click ADD PYTHON x.x TO PATH on the first screen.

kylie#1337 was banned. rip :(


# How do I use this?
since i've saw that most people don't know how to use this, i might as well tell you.
first, you're going to need python from https://python.org 

heres a direct download to the latest python version: https://www.python.org/ftp/python/3.9.0/python-3.9.0-amd64.exe

when you open this, make sure you check the 'ADD PYTHON x.x TO PATH' checkbox on the first page of the setup.

second, run the RUN ME FIRST.bat, if it closes immediately, you messed up the setup. like i said make sure you check the ADD PYTHON TO PATH checkbox
before running the main.py.

finally, after everything above has went smoothly, just run the RUN ME SECOND.bat, if it closes immediately then open a command prompt and cd to the folder with nuked in it and enter 'python main.py', if there is a missing module error, run 'pip install modulename'



# IMPORTANT !
using this tool CAN and MIGHT get your account banned, since selfbots ARE AGAINST Discord's ToS.
https://discord.com/terms
I do not condone usage of this tool, i just made it
lol





